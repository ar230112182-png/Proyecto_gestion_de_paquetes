import serial
import mysql.connector
import time
import threading
from flask import Flask, render_template

app = Flask(__name__)

# --- CONFIGURACIÓN ---
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': '02082003',
    'database': 'dh'
}
arduino_port = 'COM3' 
baud_rate = 9600

# Variable global para mostrar en la web
ultimo_usuario = {"nombre": "Esperando...", "id": "-", "fecha": "-"}

def registrar_acceso(id_huella):
    global ultimo_usuario
    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()
        
        query = "SELECT nombre_usuario FROM usuarios_h WHERE id_uh = %s"
        cursor.execute(query, (id_huella,))
        resultado = cursor.fetchone()

        if resultado:
            nombre = resultado[0]
            fecha_actual = time.strftime('%H:%M:%S')
            print(f" Acceso concedido a: {nombre}")
            
            # Actualizamos la variable para la web
            ultimo_usuario = {"nombre": nombre, "id": id_huella, "fecha": fecha_actual}
            
            log_query = "INSERT INTO logs_acceso (usuario_id, fecha) VALUES (%s, NOW())"
            cursor.execute(log_query, (id_huella,))
            conn.commit()
        else:
            print(f" ID #{id_huella} no encontrado.")
            ultimo_usuario = {"nombre": "Desconocido", "id": id_huella, "fecha": time.strftime('%H:%M:%S')}

    except mysql.connector.Error as err:
        print(f" Error DB: {err}")
    finally:
        if conn.is_connected():
            cursor.close()
            conn.close()

# --- LÓGICA DEL ARDUINO (HILO SEPARADO) ---
def lectura_arduino():
    print("--- Intentando iniciar lectura de Arduino ---")
    try:
        ser = serial.Serial(arduino_port, baud_rate, timeout=1)
        print(f"--- ÉXITO: Conectado a {arduino_port} ---")
        
        while True:
            if ser.in_waiting > 0:
                linea = ser.readline().decode('utf-8', errors='ignore').strip()
                print(f"Datos recibidos: {linea}") # Esto DEBE salir en consola
                
                if "Found ID #" in linea:
                    id_huella = linea.split('#')[1].split(' ')[0]
                    registrar_acceso(id_huella)
            
            # Pequeña pausa para no saturar el procesador
            time.sleep(0.1) 
            
    except Exception as e:
        print(f"--- ERROR CRÍTICO EN HILO: {e} ---")

# --- RUTAS DE FLASK ---
@app.route('/')
def index():
    # Pasamos los datos del último acceso al HTML
    return render_template('index.html', usuario=ultimo_usuario)

if __name__ == '__main__':
    hilo_arduino = threading.Thread(target=lectura_arduino, daemon=True)
    hilo_arduino.start()
    
    # Cambia debug a False
    app.run(debug=False, host='127.0.0.1', port=5000)